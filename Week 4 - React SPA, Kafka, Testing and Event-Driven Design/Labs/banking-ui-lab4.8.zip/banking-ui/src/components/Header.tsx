/**
 * Header component.
 *
 * Reads the current user from the auth context. When a user is logged in, shows
 * their name and a Sign-out button. Sign-out is a full-page navigation to
 * /logout (not a fetch) so the browser walks the entire logout chain: the BFF
 * clears its session and redirects to the auth server's end-session endpoint,
 * which clears the identity-provider session and returns the browser here.
 * This is RP-initiated logout (Lab 4.8) and is what prevents a silent re-login
 * after signing out.
 */

import { useAuth } from '../auth/AuthContext';

export function Header() {
  const { user } = useAuth();

  function handleSignOut() {
    window.location.href = '/logout';
  }

  return (
    <header className="header">
      <div className="header-content">
        <div>
          <h1>MD282 Bank</h1>
          <p className="tagline">Online Banking</p>
        </div>
        {user && (
          <div className="header-user">
            <span className="user-name">Hello, {user.preferredUsername}</span>
            <button
              type="button"
              onClick={handleSignOut}
              className="sign-out-button"
            >
              Sign out
            </button>
          </div>
        )}
      </div>
    </header>
  );
}
