# banking-ui -- Lab 4.7 Solution Reference

Completed React + TypeScript SPA for MD282 Module 8, integrated with the Spring
Boot BFF. This is the end state after Lab 4.5 (React fundamentals) and Lab 4.7
(BFF integration). It follows Option A: the React types match the BFF's JSON
contract directly, with no translation layer.

## What this app does

- Calls `GET /api/me` on load to detect whether the user is signed in.
- Shows a sign-in screen (an anchor to the BFF's OAuth login) when signed out.
- After login, lists accounts from `GET /api/accounts` and transfers funds via
  `POST /api/transfers`.
- Signs out via a full-page navigation to `/logout` (RP-initiated logout: the BFF
  clears its session and the auth server ends the IdP session, so the next sign-in
  prompts for credentials).

The browser never sees an OAuth token. It only holds the `BFF_SESSION` cookie.
The Vite dev proxy forwards `/api`, `/oauth2`, `/login`, and `/logout` to the BFF
so everything is one origin in development.

## Prerequisites (all three backends must be running)

| Service | Port | From |
|---|---|---|
| Authorization Server | 9000 (use `127.0.0.1`) | Lab 2-1 |
| bankapi Resource Server | 8081 | Lab 2-2, extended in Lab 4.6 |
| Banking BFF (`bankbff`) | 8080 | Lab 4.6 |

The auth server must publish issuer `http://127.0.0.1:9000`, and the
`bank-client-bff` registration must include the redirect URI
`http://localhost:5173/login/oauth2/code/bank-auth` (added in Lab 4.7 Exercise 1).

## Run

```bash
npm install
npm run dev
```

Open http://localhost:5173, click **Sign in**, and log in as `alice` / `password`.

Test users (from Lab 2-1):

- `alice` / `bob` / `carla` -- account holders (can read accounts and transfer)
- `edward` -- teller (can read and transfer)
- `audit` -- auditor (can read, but `POST /api/transfers` returns 403 because the
  auditor role lacks `transaction.create`; this is correct enforcement)

The resource server returns the same five accounts (A001 through A005) for every
user; this lab does not filter accounts by the logged-in customer.

## Data contract (matches the BFF)

- `Account`: `{ id, customerId, accountType, balance }`
- `TransferRequest`: `{ fromAccountId, toAccountId, amount }`
- `TransferResponse`: `{ transactionId, status }`
- `User` (`/api/me`): `{ subject, preferredUsername, fullName, roles }`

## Project layout

```
banking-ui/
  index.html
  package.json
  tsconfig.json
  tsconfig.node.json
  vite.config.ts          proxy to the BFF on :8080
  .eslintrc.cjs
  src/
    main.tsx              wraps App in AuthProvider
    App.tsx               auth-gated rendering, owns accounts state
    App.css               all component styles
    index.css             base styles
    api/
      types.ts            types matching the BFF JSON
      client.ts           fetch wrappers for /api/me, /api/accounts, etc.
    auth/
      AuthContext.tsx     useAuth() hook + AuthProvider
    components/
      Header.tsx          shows the user and a Sign-out button
      SignInScreen.tsx    anchor to the OAuth login URL
      AccountList.tsx     accounts table (presentational)
      TransferForm.tsx    controlled transfer form
```

## Notes

- No Mock Service Worker. This app talks to the real BFF; the three backend
  services must be up for it to show data.
- Currency is rendered with `toFixed(2)`. Swap in `Intl.NumberFormat('en-US',
  { style: 'currency', currency: 'USD' })` if you want grouped digits.
- CSRF is not enabled here; it is covered in the later application-hardening lab.
  (Because CSRF is off, `GET /logout` via navigation is accepted; once CSRF is on,
  logout becomes a POST with a token.)
- Sign-out uses `window.location.href = '/logout'` (Lab 4.8). This requires the
  Lab 4.8 backend changes: the auth server's `postLogoutRedirectUri` and the BFF's
  `OidcClientInitiatedLogoutSuccessHandler`. Without them, sign-out clears only the
  BFF session and the next login silently returns the same user.
- The transfer form respects the response `status`: a `FAILED` result (for example,
  insufficient funds) is shown as an error and does not clear the form, while only a
  `COMPLETE` result refreshes the account balances.
